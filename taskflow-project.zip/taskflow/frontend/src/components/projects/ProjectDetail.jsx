import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { projectsAPI } from '../../api';
import { useAuth } from '../../context/AuthContext';

const Avatar = ({ name, color, size = 32 }) => {
  const initials = name?.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2) || '?';
  return <div style={{ width: size, height: size, borderRadius: '50%', background: color || '#6366f1', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontSize: size * 0.36, fontWeight: 600, flexShrink: 0 }}>{initials}</div>;
};

export default function ProjectDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [project, setProject] = useState(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('overview');
  const [addMemberEmail, setAddMemberEmail] = useState('');
  const [addMemberRole, setAddMemberRole] = useState('member');
  const [addingMember, setAddingMember] = useState(false);
  const [memberError, setMemberError] = useState('');

  useEffect(() => {
    projectsAPI.getOne(id)
      .then(res => setProject(res.data.project))
      .catch(() => navigate('/projects'))
      .finally(() => setLoading(false));
  }, [id]);

  const isAdmin = project?.owner_id === user?.id || project?.members?.find(m => m.id === user?.id)?.role === 'admin';

  const handleAddMember = async (e) => {
    e.preventDefault();
    setMemberError('');
    setAddingMember(true);
    try {
      const res = await projectsAPI.addMember(id, { email: addMemberEmail, role: addMemberRole });
      setProject(p => ({ ...p, members: [...p.members, res.data.member] }));
      setAddMemberEmail('');
    } catch (err) {
      setMemberError(err.response?.data?.error || 'Failed to add member');
    } finally {
      setAddingMember(false);
    }
  };

  const handleRemoveMember = async (memberId) => {
    if (!confirm('Remove this member?')) return;
    try {
      await projectsAPI.removeMember(id, memberId);
      setProject(p => ({ ...p, members: p.members.filter(m => m.id !== memberId) }));
    } catch (err) {
      alert(err.response?.data?.error || 'Failed to remove member');
    }
  };

  const handleRoleChange = async (memberId, role) => {
    try {
      await projectsAPI.updateMemberRole(id, memberId, { role });
      setProject(p => ({ ...p, members: p.members.map(m => m.id === memberId ? { ...m, role } : m) }));
    } catch (err) {
      alert(err.response?.data?.error || 'Failed to update role');
    }
  };

  if (loading) return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: 300 }}>
      <div className="spin" style={{ width: 32, height: 32, border: '3px solid #e2e8f0', borderTopColor: '#6366f1', borderRadius: '50%' }} />
    </div>
  );

  const progress = project.task_count > 0 ? Math.round((project.completed_tasks / project.task_count) * 100) : 0;

  return (
    <div style={{ padding: '2rem', maxWidth: 1000 }} className="fade-in">
      {/* Header */}
      <div style={{ marginBottom: '1.5rem' }}>
        <Link to="/projects" style={{ color: '#64748b', fontSize: 13, display: 'inline-flex', alignItems: 'center', gap: 4, marginBottom: 12 }}>← Back to projects</Link>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <div style={{ width: 48, height: 48, borderRadius: 12, background: project.color, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22, color: '#fff', fontWeight: 700 }}>
            {project.name[0]}
          </div>
          <div>
            <h1 style={{ fontSize: 22, fontWeight: 700 }}>{project.name}</h1>
            {project.description && <p style={{ color: '#64748b', marginTop: 2 }}>{project.description}</p>}
          </div>
          <div style={{ marginLeft: 'auto', display: 'flex', gap: 10 }}>
            <Link to={`/projects/${id}/board`} style={{ background: '#6366f1', color: '#fff', padding: '9px 18px', borderRadius: 8, fontWeight: 600, fontSize: 14 }}>
              📋 Task board
            </Link>
          </div>
        </div>
      </div>

      {/* Stats row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: '2rem' }}>
        {[
          { label: 'Total tasks', value: project.task_count || 0 },
          { label: 'Completed', value: project.completed_tasks || 0 },
          { label: 'Progress', value: `${progress}%` },
          { label: 'Members', value: project.members?.length || 0 },
        ].map(s => (
          <div key={s.label} style={{ background: '#fff', borderRadius: 10, padding: '1rem', border: '1px solid #e2e8f0', textAlign: 'center' }}>
            <div style={{ fontSize: 22, fontWeight: 700, color: project.color }}>{s.value}</div>
            <div style={{ fontSize: 12, color: '#64748b', marginTop: 2 }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Progress bar */}
      <div style={{ background: '#fff', borderRadius: 10, padding: '1rem', border: '1px solid #e2e8f0', marginBottom: '2rem' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, marginBottom: 8 }}>
          <span style={{ fontWeight: 500 }}>Overall progress</span>
          <span style={{ color: '#64748b' }}>{project.completed_tasks}/{project.task_count} tasks done</span>
        </div>
        <div style={{ height: 8, background: '#f1f5f9', borderRadius: 999 }}>
          <div style={{ height: '100%', width: `${progress}%`, background: project.color, borderRadius: 999, transition: 'width 0.5s ease' }} />
        </div>
      </div>

      {/* Members section */}
      <div style={{ background: '#fff', borderRadius: 12, border: '1px solid #e2e8f0', overflow: 'hidden' }}>
        <div style={{ padding: '1rem 1.25rem', borderBottom: '1px solid #f1f5f9', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <h2 style={{ fontSize: 15, fontWeight: 600 }}>Team members</h2>
          <span style={{ fontSize: 12, color: '#64748b' }}>{project.members?.length} member{project.members?.length !== 1 ? 's' : ''}</span>
        </div>

        <div style={{ padding: '0.75rem 0' }}>
          {project.members?.map(member => (
            <div key={member.id} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 1.25rem' }}>
              <Avatar name={member.name} color={member.avatar_color} />
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 500, fontSize: 14 }}>
                  {member.name}
                  {member.id === project.owner_id && <span style={{ fontSize: 11, marginLeft: 6, color: '#f59e0b' }}>👑 Owner</span>}
                </div>
                <div style={{ fontSize: 12, color: '#94a3b8' }}>{member.email}</div>
              </div>
              {isAdmin && member.id !== project.owner_id ? (
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <select
                    value={member.role}
                    onChange={e => handleRoleChange(member.id, e.target.value)}
                    style={{ fontSize: 12, padding: '4px 8px', borderRadius: 6, border: '1px solid #e2e8f0' }}
                  >
                    <option value="member">Member</option>
                    <option value="admin">Admin</option>
                  </select>
                  {member.id !== user?.id && (
                    <button onClick={() => handleRemoveMember(member.id)} style={{ color: '#ef4444', fontSize: 18, lineHeight: 1 }}>×</button>
                  )}
                </div>
              ) : (
                <span style={{ fontSize: 11, padding: '3px 10px', borderRadius: 20, background: member.role === 'admin' ? '#ede9fe' : '#f1f5f9', color: member.role === 'admin' ? '#7c3aed' : '#64748b', fontWeight: 600 }}>
                  {member.role}
                </span>
              )}
            </div>
          ))}
        </div>

        {isAdmin && (
          <div style={{ padding: '1rem 1.25rem', borderTop: '1px solid #f1f5f9', background: '#fafafa' }}>
            <h3 style={{ fontSize: 13, fontWeight: 600, marginBottom: 10 }}>Add member</h3>
            {memberError && <div style={{ color: '#ef4444', fontSize: 12, marginBottom: 8 }}>{memberError}</div>}
            <form onSubmit={handleAddMember} style={{ display: 'flex', gap: 8 }}>
              <input
                style={{ flex: 1, padding: '8px 12px', border: '1.5px solid #e2e8f0', borderRadius: 8, fontSize: 13 }}
                type="email" placeholder="Enter email address" value={addMemberEmail}
                onChange={e => setAddMemberEmail(e.target.value)} required
              />
              <select value={addMemberRole} onChange={e => setAddMemberRole(e.target.value)} style={{ padding: '8px 12px', border: '1.5px solid #e2e8f0', borderRadius: 8, fontSize: 13 }}>
                <option value="member">Member</option>
                <option value="admin">Admin</option>
              </select>
              <button type="submit" disabled={addingMember} style={{ background: '#6366f1', color: '#fff', padding: '8px 16px', borderRadius: 8, fontWeight: 600, fontSize: 13, whiteSpace: 'nowrap' }}>
                {addingMember ? '...' : 'Add'}
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}
