import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { tasksAPI } from '../../api';
import { useAuth } from '../../context/AuthContext';

const priorityColors = { low: '#10b981', medium: '#f59e0b', high: '#ef4444', urgent: '#7c3aed' };
const statusColors = { todo: '#64748b', in_progress: '#3b82f6', in_review: '#f59e0b', done: '#10b981' };
const statusLabels = { todo: 'To Do', in_progress: 'In Progress', in_review: 'In Review', done: 'Done' };

const StatCard = ({ label, value, color, icon }) => (
  <div style={{ background: '#fff', borderRadius: 12, padding: '1.25rem', border: '1px solid #e2e8f0', display: 'flex', alignItems: 'center', gap: 14 }}>
    <div style={{ width: 44, height: 44, borderRadius: 10, background: color + '18', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22 }}>{icon}</div>
    <div>
      <div style={{ fontSize: 24, fontWeight: 700, color: '#0f172a', lineHeight: 1.2 }}>{value}</div>
      <div style={{ fontSize: 12, color: '#64748b', marginTop: 2 }}>{label}</div>
    </div>
  </div>
);

const Avatar = ({ name, color, size = 28 }) => {
  const initials = name?.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2) || '?';
  return (
    <div style={{ width: size, height: size, borderRadius: '50%', background: color || '#6366f1', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontSize: size * 0.36, fontWeight: 600, flexShrink: 0 }}>{initials}</div>
  );
};

const TaskRow = ({ task }) => {
  const overdue = task.due_date && new Date(task.due_date) < new Date() && task.status !== 'done';
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 0', borderBottom: '1px solid #f1f5f9' }}>
      <div style={{ width: 10, height: 10, borderRadius: '50%', background: priorityColors[task.priority] || '#64748b', flexShrink: 0 }} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontWeight: 500, fontSize: 13, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{task.title}</div>
        <div style={{ fontSize: 11, color: '#94a3b8' }}>{task.project_name}</div>
      </div>
      <span style={{ fontSize: 11, padding: '2px 8px', borderRadius: 20, background: statusColors[task.status] + '18', color: statusColors[task.status], fontWeight: 500 }}>
        {statusLabels[task.status]}
      </span>
      {task.due_date && (
        <span style={{ fontSize: 11, color: overdue ? '#ef4444' : '#94a3b8', whiteSpace: 'nowrap' }}>
          {new Date(task.due_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
        </span>
      )}
    </div>
  );
};

const ActivityItem = ({ item }) => {
  const actionText = {
    task_created: 'created task',
    status_changed: `moved task`,
  }[item.action] || item.action;

  return (
    <div style={{ display: 'flex', alignItems: 'flex-start', gap: 10, padding: '10px 0', borderBottom: '1px solid #f1f5f9' }}>
      <Avatar name={item.user_name} color={item.avatar_color} size={28} />
      <div style={{ flex: 1 }}>
        <span style={{ fontWeight: 500, fontSize: 12 }}>{item.user_name}</span>
        <span style={{ color: '#64748b', fontSize: 12 }}> {actionText} </span>
        {item.task_title && <span style={{ fontWeight: 500, fontSize: 12 }}>{item.task_title}</span>}
        {item.action === 'status_changed' && item.details && (
          <span style={{ color: '#64748b', fontSize: 12 }}> → {statusLabels[item.details.to]}</span>
        )}
        <div style={{ fontSize: 11, color: '#94a3b8', marginTop: 2 }}>{item.project_name}</div>
      </div>
    </div>
  );
};

export default function Dashboard() {
  const { user } = useAuth();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    tasksAPI.getDashboard()
      .then(res => setData(res.data))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) return (
    <div style={{ padding: '2rem', display: 'flex', alignItems: 'center', justifyContent: 'center', height: 300 }}>
      <div className="spin" style={{ width: 32, height: 32, border: '3px solid #e2e8f0', borderTopColor: '#6366f1', borderRadius: '50%' }} />
    </div>
  );

  const stats = data?.stats || {};

  return (
    <div style={{ padding: '2rem', maxWidth: 1100 }} className="fade-in">
      <div style={{ marginBottom: '2rem' }}>
        <h1 style={{ fontSize: 22, fontWeight: 700 }}>
          Good {new Date().getHours() < 12 ? 'morning' : new Date().getHours() < 18 ? 'afternoon' : 'evening'}, {user?.name?.split(' ')[0]} 👋
        </h1>
        <p style={{ color: '#64748b', marginTop: 4 }}>Here's what's happening with your projects</p>
      </div>

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 14, marginBottom: '2rem' }}>
        <StatCard label="Total Tasks" value={stats.total_tasks || 0} color="#6366f1" icon="📋" />
        <StatCard label="In Progress" value={stats.in_progress || 0} color="#3b82f6" icon="⚡" />
        <StatCard label="Completed" value={stats.done || 0} color="#10b981" icon="✅" />
        <StatCard label="Overdue" value={stats.overdue || 0} color="#ef4444" icon="⏰" />
        <StatCard label="Projects" value={stats.project_count || 0} color="#f59e0b" icon="📁" />
      </div>

      {/* Two columns */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
        {/* My Tasks */}
        <div style={{ background: '#fff', borderRadius: 12, padding: '1.25rem', border: '1px solid #e2e8f0' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1rem' }}>
            <h2 style={{ fontSize: 15, fontWeight: 600 }}>My tasks</h2>
            <Link to="/projects" style={{ fontSize: 12, color: '#6366f1' }}>View all</Link>
          </div>
          {data?.my_tasks?.length === 0 ? (
            <div style={{ textAlign: 'center', color: '#94a3b8', padding: '2rem 0', fontSize: 13 }}>🎉 All caught up!</div>
          ) : (
            data?.my_tasks?.map(t => <TaskRow key={t.id} task={t} />)
          )}
        </div>

        {/* Recent Activity */}
        <div style={{ background: '#fff', borderRadius: 12, padding: '1.25rem', border: '1px solid #e2e8f0' }}>
          <h2 style={{ fontSize: 15, fontWeight: 600, marginBottom: '1rem' }}>Recent activity</h2>
          {data?.recent_activity?.length === 0 ? (
            <div style={{ textAlign: 'center', color: '#94a3b8', padding: '2rem 0', fontSize: 13 }}>No activity yet</div>
          ) : (
            data?.recent_activity?.map(item => <ActivityItem key={item.id} item={item} />)
          )}
        </div>
      </div>
    </div>
  );
}
