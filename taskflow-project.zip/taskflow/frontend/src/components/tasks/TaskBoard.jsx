import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { tasksAPI, projectsAPI } from '../../api';
import { useAuth } from '../../context/AuthContext';

const STATUSES = [
  { key: 'todo', label: 'To Do', color: '#64748b', bg: '#f8fafc' },
  { key: 'in_progress', label: 'In Progress', color: '#3b82f6', bg: '#eff6ff' },
  { key: 'in_review', label: 'In Review', color: '#f59e0b', bg: '#fffbeb' },
  { key: 'done', label: 'Done', color: '#10b981', bg: '#f0fdf4' },
];

const PRIORITIES = [
  { key: 'low', label: 'Low', color: '#10b981' },
  { key: 'medium', label: 'Medium', color: '#f59e0b' },
  { key: 'high', label: 'High', color: '#ef4444' },
  { key: 'urgent', label: 'Urgent', color: '#7c3aed' },
];

const Avatar = ({ name, color, size = 24 }) => {
  const initials = name?.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2) || '?';
  return <div style={{ width: size, height: size, borderRadius: '50%', background: color || '#6366f1', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontSize: size * 0.38, fontWeight: 600, flexShrink: 0 }}>{initials}</div>;
};

const PriorityDot = ({ priority }) => {
  const p = PRIORITIES.find(x => x.key === priority);
  return <span style={{ width: 8, height: 8, borderRadius: '50%', background: p?.color || '#64748b', display: 'inline-block', marginRight: 4 }} />;
};

function TaskCard({ task, onStatusChange, onEdit, onDelete, isAdmin }) {
  const overdue = task.due_date && new Date(task.due_date) < new Date() && task.status !== 'done';

  return (
    <div style={{ background: '#fff', borderRadius: 10, padding: '12px', border: '1px solid #e2e8f0', marginBottom: 8, cursor: 'pointer', transition: 'box-shadow 0.15s' }}
      onMouseEnter={e => e.currentTarget.style.boxShadow = '0 2px 12px rgba(0,0,0,0.08)'}
      onMouseLeave={e => e.currentTarget.style.boxShadow = 'none'}
    >
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 8 }}>
        <h4 style={{ fontSize: 13, fontWeight: 500, lineHeight: 1.4, flex: 1 }}>{task.title}</h4>
        <div style={{ display: 'flex', gap: 4 }}>
          <button onClick={() => onEdit(task)} style={{ color: '#94a3b8', fontSize: 14, padding: '2px 4px' }}>✏️</button>
          {isAdmin && <button onClick={() => onDelete(task.id)} style={{ color: '#94a3b8', fontSize: 14, padding: '2px 4px' }}>🗑️</button>}
        </div>
      </div>

      {task.description && (
        <p style={{ fontSize: 11, color: '#94a3b8', marginTop: 4, overflow: 'hidden', display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical' }}>{task.description}</p>
      )}

      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 10 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <PriorityDot priority={task.priority} />
          <span style={{ fontSize: 11, color: '#64748b' }}>{task.priority}</span>
        </div>
        {task.due_date && (
          <span style={{ fontSize: 11, color: overdue ? '#ef4444' : '#94a3b8', fontWeight: overdue ? 600 : 400 }}>
            {overdue ? '⚠️ ' : ''}{new Date(task.due_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
          </span>
        )}
      </div>

      {task.assignee_name && (
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 8, paddingTop: 8, borderTop: '1px solid #f1f5f9' }}>
          <Avatar name={task.assignee_name} color={task.assignee_color} size={20} />
          <span style={{ fontSize: 11, color: '#64748b' }}>{task.assignee_name}</span>
        </div>
      )}

      {/* Quick status change */}
      <div style={{ display: 'flex', gap: 4, marginTop: 8, flexWrap: 'wrap' }}>
        {STATUSES.filter(s => s.key !== task.status).map(s => (
          <button key={s.key} onClick={(e) => { e.stopPropagation(); onStatusChange(task.id, s.key); }}
            style={{ fontSize: 10, padding: '2px 8px', borderRadius: 20, border: `1px solid ${s.color}30`, color: s.color, background: s.bg, cursor: 'pointer' }}>
            → {s.label}
          </button>
        ))}
      </div>
    </div>
  );
}

function TaskModal({ task, onClose, onSave, members, projectId, isAdmin }) {
  const { user } = useAuth();
  const [form, setForm] = useState(task || {
    title: '', description: '', priority: 'medium', status: 'todo', assignee_id: '', due_date: '', tags: []
  });
  const [saving, setSaving] = useState(false);

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const data = { ...form, assignee_id: form.assignee_id || null };
      let result;
      if (task?.id) {
        result = await tasksAPI.update(task.id, data);
      } else {
        result = await tasksAPI.create(projectId, data);
      }
      onSave(result.data.task, !!task?.id);
      onClose();
    } catch (err) {
      alert(err.response?.data?.error || 'Save failed');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100, padding: '1rem' }}>
      <div style={{ background: '#fff', borderRadius: 16, padding: '2rem', width: '100%', maxWidth: 520, maxHeight: '90vh', overflowY: 'auto' }} className="fade-in">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
          <h2 style={{ fontSize: 17, fontWeight: 700 }}>{task?.id ? 'Edit task' : 'New task'}</h2>
          <button onClick={onClose} style={{ color: '#94a3b8', fontSize: 22, lineHeight: 1 }}>×</button>
        </div>
        <form onSubmit={handleSave} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          <div>
            <label style={labelStyle}>Title *</label>
            <input style={inputStyle} value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))} placeholder="Task title" required />
          </div>
          <div>
            <label style={labelStyle}>Description</label>
            <textarea style={{ ...inputStyle, minHeight: 80, resize: 'vertical' }} value={form.description || ''} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} placeholder="Optional details..." />
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <div>
              <label style={labelStyle}>Priority</label>
              <select style={inputStyle} value={form.priority} onChange={e => setForm(p => ({ ...p, priority: e.target.value }))}>
                {PRIORITIES.map(p => <option key={p.key} value={p.key}>{p.label}</option>)}
              </select>
            </div>
            <div>
              <label style={labelStyle}>Status</label>
              <select style={inputStyle} value={form.status} onChange={e => setForm(p => ({ ...p, status: e.target.value }))}>
                {STATUSES.map(s => <option key={s.key} value={s.key}>{s.label}</option>)}
              </select>
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <div>
              <label style={labelStyle}>Assignee</label>
              <select style={inputStyle} value={form.assignee_id || ''} onChange={e => setForm(p => ({ ...p, assignee_id: e.target.value }))}>
                <option value="">Unassigned</option>
                {members?.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
              </select>
            </div>
            <div>
              <label style={labelStyle}>Due date</label>
              <input style={inputStyle} type="date" value={form.due_date ? form.due_date.split('T')[0] : ''} onChange={e => setForm(p => ({ ...p, due_date: e.target.value }))} />
            </div>
          </div>
          <div style={{ display: 'flex', gap: 10, marginTop: 8 }}>
            <button type="button" onClick={onClose} style={{ flex: 1, padding: '10px', border: '1px solid #e2e8f0', borderRadius: 8, fontWeight: 500 }}>Cancel</button>
            <button type="submit" disabled={saving} style={{ flex: 1, background: '#6366f1', color: '#fff', padding: '10px', borderRadius: 8, fontWeight: 600 }}>
              {saving ? 'Saving...' : (task?.id ? 'Save changes' : 'Create task')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default function TaskBoard() {
  const { id: projectId } = useParams();
  const { user } = useAuth();
  const [tasks, setTasks] = useState([]);
  const [project, setProject] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editTask, setEditTask] = useState(null);
  const [filterAssignee, setFilterAssignee] = useState('');
  const [filterPriority, setFilterPriority] = useState('');
  const [search, setSearch] = useState('');

  useEffect(() => {
    Promise.all([
      projectsAPI.getOne(projectId),
      tasksAPI.getByProject(projectId),
    ]).then(([projRes, taskRes]) => {
      setProject(projRes.data.project);
      setTasks(taskRes.data.tasks);
    }).catch(console.error).finally(() => setLoading(false));
  }, [projectId]);

  const isAdmin = project?.owner_id === user?.id || project?.members?.find(m => m.id === user?.id)?.role === 'admin';

  const handleStatusChange = async (taskId, newStatus) => {
    try {
      const res = await tasksAPI.update(taskId, { status: newStatus });
      setTasks(prev => prev.map(t => t.id === taskId ? res.data.task : t));
    } catch (err) {
      alert('Failed to update status');
    }
  };

  const handleSaveTask = (task, isEdit) => {
    if (isEdit) {
      setTasks(prev => prev.map(t => t.id === task.id ? task : t));
    } else {
      setTasks(prev => [...prev, task]);
    }
  };

  const handleDeleteTask = async (taskId) => {
    if (!confirm('Delete this task?')) return;
    try {
      await tasksAPI.delete(taskId);
      setTasks(prev => prev.filter(t => t.id !== taskId));
    } catch (err) {
      alert('Failed to delete task');
    }
  };

  const filteredTasks = tasks.filter(t => {
    if (filterAssignee && t.assignee_id !== filterAssignee) return false;
    if (filterPriority && t.priority !== filterPriority) return false;
    if (search && !t.title.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  if (loading) return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: 300 }}>
      <div className="spin" style={{ width: 32, height: 32, border: '3px solid #e2e8f0', borderTopColor: '#6366f1', borderRadius: '50%' }} />
    </div>
  );

  return (
    <div style={{ padding: '1.5rem', minHeight: '100vh' }} className="fade-in">
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: '1.25rem', flexWrap: 'wrap' }}>
        <Link to={`/projects/${projectId}`} style={{ color: '#64748b', fontSize: 13 }}>← Back</Link>
        <h1 style={{ fontSize: 18, fontWeight: 700, flex: 1 }}>{project?.name} — Task Board</h1>
        <button onClick={() => { setEditTask(null); setShowModal(true); }}
          style={{ background: '#6366f1', color: '#fff', padding: '8px 16px', borderRadius: 8, fontWeight: 600, fontSize: 13 }}>
          + New task
        </button>
      </div>

      {/* Filters */}
      <div style={{ display: 'flex', gap: 10, marginBottom: '1.25rem', flexWrap: 'wrap', background: '#fff', padding: '12px', borderRadius: 10, border: '1px solid #e2e8f0' }}>
        <input
          style={{ padding: '7px 12px', border: '1px solid #e2e8f0', borderRadius: 8, fontSize: 13, minWidth: 180 }}
          placeholder="🔍 Search tasks..." value={search} onChange={e => setSearch(e.target.value)}
        />
        <select style={{ padding: '7px 12px', border: '1px solid #e2e8f0', borderRadius: 8, fontSize: 13 }} value={filterAssignee} onChange={e => setFilterAssignee(e.target.value)}>
          <option value="">All assignees</option>
          {project?.members?.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
        </select>
        <select style={{ padding: '7px 12px', border: '1px solid #e2e8f0', borderRadius: 8, fontSize: 13 }} value={filterPriority} onChange={e => setFilterPriority(e.target.value)}>
          <option value="">All priorities</option>
          {PRIORITIES.map(p => <option key={p.key} value={p.key}>{p.label}</option>)}
        </select>
        <span style={{ marginLeft: 'auto', fontSize: 12, color: '#94a3b8', alignSelf: 'center' }}>
          {filteredTasks.length} task{filteredTasks.length !== 1 ? 's' : ''}
        </span>
      </div>

      {/* Kanban columns */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '1rem', alignItems: 'start' }}>
        {STATUSES.map(status => {
          const colTasks = filteredTasks.filter(t => t.status === status.key);
          return (
            <div key={status.key} style={{ background: status.bg, borderRadius: 12, padding: '12px', border: `1px solid ${status.color}20` }}>
              {/* Column header */}
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
                <div style={{ width: 10, height: 10, borderRadius: '50%', background: status.color }} />
                <span style={{ fontWeight: 600, fontSize: 13, color: status.color }}>{status.label}</span>
                <span style={{ marginLeft: 'auto', background: status.color + '20', color: status.color, borderRadius: 20, fontSize: 11, padding: '1px 8px', fontWeight: 600 }}>
                  {colTasks.length}
                </span>
              </div>

              {/* Tasks */}
              {colTasks.map(task => (
                <TaskCard
                  key={task.id}
                  task={task}
                  onStatusChange={handleStatusChange}
                  onEdit={(t) => { setEditTask(t); setShowModal(true); }}
                  onDelete={handleDeleteTask}
                  isAdmin={isAdmin}
                />
              ))}

              {colTasks.length === 0 && (
                <div style={{ textAlign: 'center', color: '#94a3b8', fontSize: 12, padding: '1.5rem 0' }}>No tasks</div>
              )}

              {/* Add task inline */}
              <button onClick={() => { setEditTask({ status: status.key }); setShowModal(true); }}
                style={{ width: '100%', padding: '8px', border: `1.5px dashed ${status.color}40`, borderRadius: 8, color: status.color, fontSize: 12, fontWeight: 500, marginTop: 4 }}>
                + Add task
              </button>
            </div>
          );
        })}
      </div>

      {/* Task Modal */}
      {showModal && (
        <TaskModal
          task={editTask?.id ? editTask : (editTask?.status ? { ...editTask } : null)}
          onClose={() => { setShowModal(false); setEditTask(null); }}
          onSave={handleSaveTask}
          members={project?.members}
          projectId={projectId}
          isAdmin={isAdmin}
        />
      )}
    </div>
  );
}

const labelStyle = { fontSize: 12, fontWeight: 500, color: '#374151', display: 'block', marginBottom: 5 };
const inputStyle = { width: '100%', padding: '9px 12px', border: '1.5px solid #e2e8f0', borderRadius: 8, fontSize: 13, outline: 'none' };
