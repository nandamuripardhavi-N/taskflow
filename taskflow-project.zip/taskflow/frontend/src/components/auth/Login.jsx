import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      await login(form.email, form.password);
      navigate('/dashboard');
    } catch (err) {
      setError(err.response?.data?.error || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  const fillDemo = (type) => {
    if (type === 'admin') setForm({ email: 'admin@taskflow.com', password: 'password123' });
    else setForm({ email: 'member@taskflow.com', password: 'password123' });
  };

  return (
    <div style={styles.page}>
      <div style={styles.card} className="fade-in">
        <div style={styles.logo}>
          <svg width="36" height="36" viewBox="0 0 36 36" fill="none">
            <rect width="36" height="36" rx="10" fill="#6366f1"/>
            <path d="M9 18l6 6 12-12" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          <span style={styles.logoText}>TaskFlow</span>
        </div>
        <h1 style={styles.title}>Welcome back</h1>
        <p style={styles.subtitle}>Sign in to your workspace</p>

        {error && <div style={styles.error}>{error}</div>}

        <form onSubmit={handleSubmit} style={styles.form}>
          <div style={styles.field}>
            <label style={styles.label}>Email</label>
            <input
              style={styles.input}
              type="email"
              value={form.email}
              onChange={e => setForm(p => ({ ...p, email: e.target.value }))}
              placeholder="you@example.com"
              required
            />
          </div>
          <div style={styles.field}>
            <label style={styles.label}>Password</label>
            <input
              style={styles.input}
              type="password"
              value={form.password}
              onChange={e => setForm(p => ({ ...p, password: e.target.value }))}
              placeholder="••••••••"
              required
            />
          </div>
          <button type="submit" style={styles.btn} disabled={loading}>
            {loading ? 'Signing in...' : 'Sign in'}
          </button>
        </form>

        <div style={styles.divider}><span>Demo accounts</span></div>
        <div style={styles.demoRow}>
          <button style={styles.demoBtn} onClick={() => fillDemo('admin')}>
            👑 Admin account
          </button>
          <button style={styles.demoBtn} onClick={() => fillDemo('member')}>
            👤 Member account
          </button>
        </div>

        <p style={styles.footer}>
          No account? <Link to="/signup" style={{ color: '#6366f1', fontWeight: 500 }}>Sign up</Link>
        </p>
      </div>
    </div>
  );
}

const styles = {
  page: { minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'linear-gradient(135deg, #f0f0ff 0%, #f8f9fc 50%, #f0fff4 100%)', padding: '1rem' },
  card: { background: '#fff', borderRadius: 16, padding: '2.5rem', width: '100%', maxWidth: 420, boxShadow: '0 8px 40px rgba(99,102,241,0.12)' },
  logo: { display: 'flex', alignItems: 'center', gap: 10, marginBottom: '1.5rem' },
  logoText: { fontSize: 22, fontWeight: 700, color: '#0f172a' },
  title: { fontSize: 22, fontWeight: 700, marginBottom: 4 },
  subtitle: { color: '#64748b', marginBottom: '1.5rem' },
  error: { background: '#fef2f2', color: '#dc2626', padding: '10px 14px', borderRadius: 8, marginBottom: '1rem', fontSize: 13 },
  form: { display: 'flex', flexDirection: 'column', gap: '1rem' },
  field: { display: 'flex', flexDirection: 'column', gap: 6 },
  label: { fontSize: 13, fontWeight: 500, color: '#374151' },
  input: { padding: '10px 14px', border: '1.5px solid #e2e8f0', borderRadius: 8, fontSize: 14, outline: 'none', transition: 'border-color 0.15s' },
  btn: { background: '#6366f1', color: '#fff', padding: '11px', borderRadius: 8, fontWeight: 600, fontSize: 14, marginTop: 4, transition: 'background 0.15s' },
  divider: { textAlign: 'center', color: '#94a3b8', fontSize: 12, margin: '1.25rem 0', position: 'relative', borderTop: '1px solid #e2e8f0', paddingTop: 12 },
  demoRow: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: '1.25rem' },
  demoBtn: { padding: '8px', border: '1.5px solid #e2e8f0', borderRadius: 8, fontSize: 12, fontWeight: 500, color: '#374151', background: '#f8fafc', cursor: 'pointer' },
  footer: { textAlign: 'center', color: '#64748b', fontSize: 13 },
};
