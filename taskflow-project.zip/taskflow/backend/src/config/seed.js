const pool = require('./database');
const bcrypt = require('bcryptjs');

const seed = async () => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // Demo users
    const adminPassword = await bcrypt.hash('password123', 12);
    const memberPassword = await bcrypt.hash('password123', 12);

    const adminResult = await client.query(`
      INSERT INTO users (name, email, password, avatar_color)
      VALUES ('Alex Admin', 'admin@taskflow.com', $1, '#6366f1')
      ON CONFLICT (email) DO UPDATE SET name = EXCLUDED.name
      RETURNING id
    `, [adminPassword]);

    const memberResult = await client.query(`
      INSERT INTO users (name, email, password, avatar_color)
      VALUES ('Morgan Member', 'member@taskflow.com', $1, '#10b981')
      ON CONFLICT (email) DO UPDATE SET name = EXCLUDED.name
      RETURNING id
    `, [memberPassword]);

    const adminId = adminResult.rows[0].id;
    const memberId = memberResult.rows[0].id;

    // Demo project
    const projResult = await client.query(`
      INSERT INTO projects (name, description, status, color, owner_id, due_date)
      VALUES ('Website Redesign', 'Complete overhaul of the company website with modern design', 'active', '#6366f1', $1, NOW() + INTERVAL '30 days')
      RETURNING id
    `, [adminId]);

    const projectId = projResult.rows[0].id;

    // Add members to project
    await client.query(`
      INSERT INTO project_members (project_id, user_id, role)
      VALUES ($1, $2, 'admin'), ($1, $3, 'member')
      ON CONFLICT DO NOTHING
    `, [projectId, adminId, memberId]);

    // Demo tasks
    const tasks = [
      { title: 'Design new homepage', status: 'done', priority: 'high', assignee: adminId },
      { title: 'Implement responsive navigation', status: 'in_progress', priority: 'high', assignee: memberId },
      { title: 'Write API documentation', status: 'in_review', priority: 'medium', assignee: adminId },
      { title: 'Set up CI/CD pipeline', status: 'todo', priority: 'urgent', assignee: memberId },
      { title: 'User testing & feedback', status: 'todo', priority: 'medium', assignee: null },
      { title: 'Performance optimization', status: 'todo', priority: 'low', assignee: memberId },
    ];

    for (const task of tasks) {
      await client.query(`
        INSERT INTO tasks (title, status, priority, project_id, assignee_id, created_by, due_date)
        VALUES ($1, $2, $3, $4, $5, $6, NOW() + INTERVAL '14 days')
      `, [task.title, task.status, task.priority, projectId, task.assignee, adminId]);
    }

    await client.query('COMMIT');
    console.log('✅ Seed completed');
    console.log('Demo credentials:');
    console.log('  Admin - admin@taskflow.com / password123');
    console.log('  Member - member@taskflow.com / password123');
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('❌ Seed failed:', err);
  } finally {
    client.release();
    pool.end();
  }
};

seed().catch(console.error);
