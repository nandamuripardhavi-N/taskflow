const jwt = require('jsonwebtoken');
const pool = require('../config/database');

const authenticate = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'No token provided' });
    }

    const token = authHeader.split(' ')[1];
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    const result = await pool.query(
      'SELECT id, name, email, avatar_color FROM users WHERE id = $1',
      [decoded.userId]
    );

    if (!result.rows.length) {
      return res.status(401).json({ error: 'User not found' });
    }

    req.user = result.rows[0];
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid token' });
  }
};

// Check if user is project admin
const requireProjectAdmin = async (req, res, next) => {
  try {
    const projectId = req.params.projectId || req.body.project_id;
    const userId = req.user.id;

    const result = await pool.query(
      `SELECT role FROM project_members WHERE project_id = $1 AND user_id = $2`,
      [projectId, userId]
    );

    if (!result.rows.length) {
      return res.status(403).json({ error: 'Not a project member' });
    }

    const member = result.rows[0];
    // Project owner is always admin
    const ownerResult = await pool.query(
      'SELECT owner_id FROM projects WHERE id = $1',
      [projectId]
    );

    if (ownerResult.rows[0]?.owner_id === userId || member.role === 'admin') {
      req.projectRole = 'admin';
      return next();
    }

    return res.status(403).json({ error: 'Admin access required' });
  } catch (err) {
    return res.status(500).json({ error: 'Server error' });
  }
};

// Check if user is project member
const requireProjectMember = async (req, res, next) => {
  try {
    const projectId = req.params.projectId || req.params.id;
    const userId = req.user.id;

    const result = await pool.query(
      `SELECT pm.role, p.owner_id 
       FROM project_members pm 
       JOIN projects p ON p.id = pm.project_id
       WHERE pm.project_id = $1 AND pm.user_id = $2`,
      [projectId, userId]
    );

    if (!result.rows.length) {
      return res.status(403).json({ error: 'Not a project member' });
    }

    req.projectRole = result.rows[0].owner_id === userId ? 'admin' : result.rows[0].role;
    next();
  } catch (err) {
    return res.status(500).json({ error: 'Server error' });
  }
};

module.exports = { authenticate, requireProjectAdmin, requireProjectMember };
