const { validationResult } = require('express-validator');
const pool = require('../config/database');

const getTasks = async (req, res) => {
  const { projectId } = req.params;
  const { status, priority, assignee, search } = req.query;

  try {
    let query = `
      SELECT 
        t.*,
        u.name as assignee_name, u.avatar_color as assignee_color,
        c.name as creator_name
      FROM tasks t
      LEFT JOIN users u ON u.id = t.assignee_id
      JOIN users c ON c.id = t.created_by
      WHERE t.project_id = $1
    `;
    const params = [projectId];
    let paramIdx = 2;

    if (status) { query += ` AND t.status = $${paramIdx++}`; params.push(status); }
    if (priority) { query += ` AND t.priority = $${paramIdx++}`; params.push(priority); }
    if (assignee) { query += ` AND t.assignee_id = $${paramIdx++}`; params.push(assignee); }
    if (search) { query += ` AND t.title ILIKE $${paramIdx++}`; params.push(`%${search}%`); }

    query += ' ORDER BY t.position ASC, t.created_at DESC';

    const result = await pool.query(query, params);
    res.json({ tasks: result.rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

const getTask = async (req, res) => {
  const { id } = req.params;
  try {
    const result = await pool.query(`
      SELECT t.*, u.name as assignee_name, u.avatar_color as assignee_color, c.name as creator_name
      FROM tasks t
      LEFT JOIN users u ON u.id = t.assignee_id
      JOIN users c ON c.id = t.created_by
      WHERE t.id = $1
    `, [id]);

    if (!result.rows.length) return res.status(404).json({ error: 'Task not found' });

    const comments = await pool.query(`
      SELECT tc.*, u.name as user_name, u.avatar_color
      FROM task_comments tc
      JOIN users u ON u.id = tc.user_id
      WHERE tc.task_id = $1
      ORDER BY tc.created_at ASC
    `, [id]);

    res.json({ task: { ...result.rows[0], comments: comments.rows } });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
};

const createTask = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const { projectId } = req.params;
  const { title, description, priority, assignee_id, due_date, tags } = req.body;

  try {
    const maxPos = await pool.query('SELECT COALESCE(MAX(position), 0) as max FROM tasks WHERE project_id = $1', [projectId]);
    const position = maxPos.rows[0].max + 1;

    const result = await pool.query(`
      INSERT INTO tasks (title, description, priority, project_id, assignee_id, created_by, due_date, tags, position)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
      RETURNING *
    `, [title, description, priority || 'medium', projectId, assignee_id || null, req.user.id, due_date || null, tags || [], position]);

    // Log activity
    await pool.query(
      'INSERT INTO activity_log (user_id, project_id, task_id, action, details) VALUES ($1, $2, $3, $4, $5)',
      [req.user.id, projectId, result.rows[0].id, 'task_created', { title }]
    );

    res.status(201).json({ task: result.rows[0] });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

const updateTask = async (req, res) => {
  const { id } = req.params;
  const { title, description, status, priority, assignee_id, due_date, tags } = req.body;

  try {
    const old = await pool.query('SELECT * FROM tasks WHERE id = $1', [id]);
    if (!old.rows.length) return res.status(404).json({ error: 'Task not found' });

    const result = await pool.query(`
      UPDATE tasks SET
        title = COALESCE($1, title),
        description = COALESCE($2, description),
        status = COALESCE($3, status),
        priority = COALESCE($4, priority),
        assignee_id = CASE WHEN $5::uuid IS NOT NULL THEN $5 ELSE assignee_id END,
        due_date = COALESCE($6, due_date),
        tags = COALESCE($7, tags),
        updated_at = NOW()
      WHERE id = $8 RETURNING *
    `, [title, description, status, priority, assignee_id || null, due_date || null, tags || null, id]);

    // Log status changes
    if (status && status !== old.rows[0].status) {
      await pool.query(
        'INSERT INTO activity_log (user_id, project_id, task_id, action, details) VALUES ($1, $2, $3, $4, $5)',
        [req.user.id, old.rows[0].project_id, id, 'status_changed', { from: old.rows[0].status, to: status }]
      );
    }

    res.json({ task: result.rows[0] });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

const deleteTask = async (req, res) => {
  const { id } = req.params;
  try {
    const task = await pool.query('SELECT * FROM tasks WHERE id = $1', [id]);
    if (!task.rows.length) return res.status(404).json({ error: 'Task not found' });

    // Only creator or project admin can delete
    if (task.rows[0].created_by !== req.user.id && req.projectRole !== 'admin') {
      return res.status(403).json({ error: 'Insufficient permissions' });
    }

    await pool.query('DELETE FROM tasks WHERE id = $1', [id]);
    res.json({ message: 'Task deleted' });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
};

const addComment = async (req, res) => {
  const { id } = req.params;
  const { content } = req.body;
  if (!content?.trim()) return res.status(400).json({ error: 'Content required' });

  try {
    const result = await pool.query(
      'INSERT INTO task_comments (task_id, user_id, content) VALUES ($1, $2, $3) RETURNING *',
      [id, req.user.id, content]
    );

    const comment = await pool.query(`
      SELECT tc.*, u.name as user_name, u.avatar_color
      FROM task_comments tc JOIN users u ON u.id = tc.user_id
      WHERE tc.id = $1
    `, [result.rows[0].id]);

    res.status(201).json({ comment: comment.rows[0] });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
};

// Dashboard stats
const getDashboard = async (req, res) => {
  try {
    const userId = req.user.id;

    const stats = await pool.query(`
      SELECT
        COUNT(DISTINCT t.id) as total_tasks,
        COUNT(DISTINCT t.id) FILTER (WHERE t.status = 'todo') as todo,
        COUNT(DISTINCT t.id) FILTER (WHERE t.status = 'in_progress') as in_progress,
        COUNT(DISTINCT t.id) FILTER (WHERE t.status = 'done') as done,
        COUNT(DISTINCT t.id) FILTER (WHERE t.due_date < NOW() AND t.status != 'done') as overdue,
        COUNT(DISTINCT p.id) as project_count
      FROM project_members pm
      JOIN projects p ON p.id = pm.project_id
      LEFT JOIN tasks t ON t.project_id = p.id AND (t.assignee_id = $1 OR pm.role = 'admin')
      WHERE pm.user_id = $1
    `, [userId]);

    const myTasks = await pool.query(`
      SELECT t.*, p.name as project_name, p.color as project_color,
        u.name as assignee_name, u.avatar_color as assignee_color
      FROM tasks t
      JOIN projects p ON p.id = t.project_id
      JOIN project_members pm ON pm.project_id = p.id AND pm.user_id = $1
      LEFT JOIN users u ON u.id = t.assignee_id
      WHERE t.assignee_id = $1 AND t.status != 'done'
      ORDER BY t.due_date ASC NULLS LAST, t.priority DESC
      LIMIT 10
    `, [userId]);

    const recentActivity = await pool.query(`
      SELECT al.*, u.name as user_name, u.avatar_color, t.title as task_title, p.name as project_name
      FROM activity_log al
      JOIN users u ON u.id = al.user_id
      LEFT JOIN tasks t ON t.id = al.task_id
      LEFT JOIN projects p ON p.id = al.project_id
      JOIN project_members pm ON pm.project_id = al.project_id AND pm.user_id = $1
      ORDER BY al.created_at DESC
      LIMIT 10
    `, [userId]);

    res.json({
      stats: stats.rows[0],
      my_tasks: myTasks.rows,
      recent_activity: recentActivity.rows
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

module.exports = { getTasks, getTask, createTask, updateTask, deleteTask, addComment, getDashboard };
