const { validationResult } = require('express-validator');
const pool = require('../config/database');

const getProjects = async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        p.*,
        u.name as owner_name,
        pm.role as my_role,
        COUNT(DISTINCT t.id) as task_count,
        COUNT(DISTINCT t.id) FILTER (WHERE t.status = 'done') as completed_tasks,
        COUNT(DISTINCT pm2.user_id) as member_count
      FROM projects p
      JOIN project_members pm ON pm.project_id = p.id AND pm.user_id = $1
      JOIN users u ON u.id = p.owner_id
      LEFT JOIN tasks t ON t.project_id = p.id
      LEFT JOIN project_members pm2 ON pm2.project_id = p.id
      GROUP BY p.id, u.name, pm.role
      ORDER BY p.created_at DESC
    `, [req.user.id]);

    res.json({ projects: result.rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

const getProject = async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query(`
      SELECT p.*, u.name as owner_name,
        COUNT(DISTINCT t.id) as task_count,
        COUNT(DISTINCT t.id) FILTER (WHERE t.status = 'done') as completed_tasks
      FROM projects p
      JOIN users u ON u.id = p.owner_id
      LEFT JOIN tasks t ON t.project_id = p.id
      WHERE p.id = $1
      GROUP BY p.id, u.name
    `, [id]);

    if (!result.rows.length) return res.status(404).json({ error: 'Project not found' });

    // Get members
    const members = await pool.query(`
      SELECT u.id, u.name, u.email, u.avatar_color, pm.role, pm.joined_at
      FROM project_members pm
      JOIN users u ON u.id = pm.user_id
      WHERE pm.project_id = $1
      ORDER BY pm.role DESC, pm.joined_at ASC
    `, [id]);

    res.json({ project: { ...result.rows[0], members: members.rows } });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
};

const createProject = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const { name, description, color, due_date } = req.body;
  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    const result = await client.query(
      'INSERT INTO projects (name, description, color, owner_id, due_date) VALUES ($1, $2, $3, $4, $5) RETURNING *',
      [name, description, color || '#6366f1', req.user.id, due_date || null]
    );

    const project = result.rows[0];

    // Auto-add owner as admin
    await client.query(
      'INSERT INTO project_members (project_id, user_id, role) VALUES ($1, $2, $3)',
      [project.id, req.user.id, 'admin']
    );

    await client.query('COMMIT');
    res.status(201).json({ project: { ...project, my_role: 'admin', member_count: 1, task_count: 0, completed_tasks: 0 } });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  } finally {
    client.release();
  }
};

const updateProject = async (req, res) => {
  const { id } = req.params;
  const { name, description, status, color, due_date } = req.body;

  try {
    const result = await pool.query(
      `UPDATE projects SET 
        name = COALESCE($1, name),
        description = COALESCE($2, description),
        status = COALESCE($3, status),
        color = COALESCE($4, color),
        due_date = COALESCE($5, due_date),
        updated_at = NOW()
      WHERE id = $6 RETURNING *`,
      [name, description, status, color, due_date, id]
    );

    if (!result.rows.length) return res.status(404).json({ error: 'Project not found' });
    res.json({ project: result.rows[0] });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
};

const deleteProject = async (req, res) => {
  const { id } = req.params;
  try {
    const check = await pool.query('SELECT owner_id FROM projects WHERE id = $1', [id]);
    if (!check.rows.length) return res.status(404).json({ error: 'Project not found' });
    if (check.rows[0].owner_id !== req.user.id) return res.status(403).json({ error: 'Only owner can delete project' });

    await pool.query('DELETE FROM projects WHERE id = $1', [id]);
    res.json({ message: 'Project deleted' });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
};

const addMember = async (req, res) => {
  const { projectId } = req.params;
  const { email, role = 'member' } = req.body;

  try {
    const user = await pool.query('SELECT id, name, email, avatar_color FROM users WHERE email = $1', [email]);
    if (!user.rows.length) return res.status(404).json({ error: 'User not found' });

    const existing = await pool.query(
      'SELECT id FROM project_members WHERE project_id = $1 AND user_id = $2',
      [projectId, user.rows[0].id]
    );
    if (existing.rows.length) return res.status(409).json({ error: 'Already a member' });

    await pool.query(
      'INSERT INTO project_members (project_id, user_id, role) VALUES ($1, $2, $3)',
      [projectId, user.rows[0].id, role]
    );

    res.status(201).json({ member: { ...user.rows[0], role } });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
};

const updateMemberRole = async (req, res) => {
  const { projectId, userId } = req.params;
  const { role } = req.body;

  try {
    const project = await pool.query('SELECT owner_id FROM projects WHERE id = $1', [projectId]);
    if (project.rows[0]?.owner_id === userId) {
      return res.status(403).json({ error: 'Cannot change owner role' });
    }

    await pool.query(
      'UPDATE project_members SET role = $1 WHERE project_id = $2 AND user_id = $3',
      [role, projectId, userId]
    );
    res.json({ message: 'Role updated' });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
};

const removeMember = async (req, res) => {
  const { projectId, userId } = req.params;

  try {
    const project = await pool.query('SELECT owner_id FROM projects WHERE id = $1', [projectId]);
    if (project.rows[0]?.owner_id === userId) {
      return res.status(403).json({ error: 'Cannot remove project owner' });
    }

    await pool.query('DELETE FROM project_members WHERE project_id = $1 AND user_id = $2', [projectId, userId]);
    res.json({ message: 'Member removed' });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
};

module.exports = { getProjects, getProject, createProject, updateProject, deleteProject, addMember, updateMemberRole, removeMember };
