const express = require('express');
const { body } = require('express-validator');
const { getTasks, getTask, createTask, updateTask, deleteTask, addComment, getDashboard } = require('../controllers/taskController');
const { authenticate, requireProjectMember } = require('../middleware/auth');

const router = express.Router();

router.use(authenticate);

// Dashboard
router.get('/dashboard', getDashboard);

// Project tasks
router.get('/project/:projectId', requireProjectMember, getTasks);
router.post('/project/:projectId', requireProjectMember, [
  body('title').trim().isLength({ min: 1 }).withMessage('Task title required'),
], createTask);

// Single task operations
router.get('/:id', getTask);
router.patch('/:id', updateTask);
router.delete('/:id', deleteTask);
router.post('/:id/comments', addComment);

module.exports = router;
