const express = require('express');
const { body } = require('express-validator');
const {
  getProjects, getProject, createProject, updateProject, deleteProject,
  addMember, updateMemberRole, removeMember
} = require('../controllers/projectController');
const { authenticate, requireProjectAdmin, requireProjectMember } = require('../middleware/auth');

const router = express.Router();

router.use(authenticate);

router.get('/', getProjects);
router.post('/', [
  body('name').trim().isLength({ min: 2 }).withMessage('Project name required'),
], createProject);

router.get('/:id', requireProjectMember, getProject);
router.patch('/:id', requireProjectAdmin, updateProject);
router.delete('/:id', deleteProject);

// Member management (admin only)
router.post('/:projectId/members', requireProjectAdmin, addMember);
router.patch('/:projectId/members/:userId', requireProjectAdmin, updateMemberRole);
router.delete('/:projectId/members/:userId', requireProjectAdmin, removeMember);

module.exports = router;
